clear;
close all;
taille_ecran = get(0,'ScreenSize');
L = taille_ecran(3);
H = taille_ecran(4);
sigma = 5;
H_size = 3*sigma;
mugf = 2;
gammagf = 0.01;
iterations = 300;

% Lecture et affichage de l'image a segmenter :
I = imread('pears.png');
[nb_lignes,nb_colonnes,nb_canaux] = size(I);
if nb_canaux==3
	I = rgb2gray(I);
end
I = double(I);
I = I/max(I(:));
figure('Name','Champ de force externe','Position',[0.1*L,0.1*H,0.9*L,0.7*H]);
subplot(1,2,1);
imagesc(I);
colormap gray;
axis image off;
title('Image a segmenter','FontSize',20);
	
% Champ de force externe :
%noyau Gaussien
G0 = fspecial("gaussian",H_size,sigma);
C = conv2(I,G0,"same");
[Ix,Iy] = gradient(C);
Eext = -(Ix.*Ix+Iy.*Iy);
%Calcul de GVF
[Fx0,Fy0] = gradient(Eext);
valeur_e = norm(gradient(Eext))^2;
[Fx,Fy] = gradient(Eext);
for i =1:iterations
    laplx = del2(Fx);
    terme_droite_x = valeur_e * (Fx-Fx0) - mugf*laplx;
    Fx = Fx  - gammagf*terme_droite_x;
    laplx = del2(Fy);
    terme_droite_x = valeur_e *(Fy - Fy0) - mugf*laplx;
    Fx = Fx - gammagf*terme_droite_x;
end

% Normalisation du champ de force externe pour l'affichage :
norme = sqrt(Fx.*Fx+Fy.*Fy);
Fx_normalise = Fx./(norme+eps);
Fy_normalise = Fy./(norme+eps);
% Affichage du champ de force externe :
subplot(1,2,2);
imagesc(I);
colormap gray;
axis image off;
hold on;
pas_fleches = 5;
taille_fleches = 1;
[x,y] = meshgrid(1:pas_fleches:nb_colonnes,1:pas_fleches:nb_lignes);
Fx_normalise_quiver = Fx_normalise(1:pas_fleches:nb_lignes,1:pas_fleches:nb_colonnes);
Fy_normalise_quiver = Fy_normalise(1:pas_fleches:nb_lignes,1:pas_fleches:nb_colonnes);
hq = quiver(x,y,Fx_normalise_quiver,Fy_normalise_quiver,taille_fleches);
set(hq,'LineWidth',1,'Color',[1,0,0]);
title('Champ de force externe elementaire','FontSize',20);

save force_externe;
